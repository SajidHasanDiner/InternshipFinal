import React from 'react';
import { createBrowserRouter } from "react-router-dom";
import Category from '../page/Category';
import ProductDetailsPage from '../page/ProductDetailsPage';
import Cartpage from '../page/cartpage';
import Productlist from './../components/Productlist';
import Home from './../page/Home';




export const router = createBrowserRouter([
  {
    path: "/",
    element: <Home/>,
  },
    {
      path: "/product",
      element: <Productlist />,
    },
    {
      path: "/product/:productid",
      element: <ProductDetailsPage />,
    },
    {
      path: "/product/category/:categoryName",
      element: <Category />,
    },
    {
      path: "/cart",
      element: <Cartpage />,
    },

  ]);