import React from 'react'
import CategoryItems from '../components/CategoryItems'
import NavbarHome from '../components/NavbarHome'
import Footer from '../components/footer'

function Category() {
  return (
    <div>
        <NavbarHome/>
        <CategoryItems/>
        <Footer />
    </div>
  )
}

export default Category
