import React from 'react';
import NavbarHome from '../components/NavbarHome';
import Footer from '../components/footer';
import ProductDetails from './../components/ProductDetails';

function ProductDetailsPage() {
  return (
    <div>
       <NavbarHome />
      <ProductDetails />
      <Footer />
    </div>
  )
}

export default ProductDetailsPage
