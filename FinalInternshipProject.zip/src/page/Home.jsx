import React from 'react';
import NavbarHome from '../components/NavbarHome';
import Productlist from '../components/Productlist';
import Carousel from '../components/carousel';
import Footer from '../components/footer';

function Home() {
  return (
    <div>
       <NavbarHome />
       <Carousel />
      <Productlist />
      <Footer />
      {/* <ProductDetails /> */}
    </div>
  )
}

export default Home
