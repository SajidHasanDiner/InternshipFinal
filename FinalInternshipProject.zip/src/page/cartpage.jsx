import React from 'react'
import NavbarHome from '../components/NavbarHome'
import Cart from '../components/cart'
import Footer from '../components/footer'

function Cartpage() {
  return (
    <div>
      <NavbarHome />
      <Cart />
      <Footer />
    </div>
  )
}

export default Cartpage
