import React, { useEffect, useState } from "react";
import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import NavDropdown from "react-bootstrap/NavDropdown";
import Navbar from "react-bootstrap/Navbar";
import { IoCartOutline } from "react-icons/io5";
import { Link } from 'react-router-dom';
import "./navbar.css";

function NavbarHome() {
  const [data, setData] = useState([]);

  useEffect(() => {
    fetch("https://fakestoreapi.com/products/categories")
      .then((response) => response.json())
      .then((data) => setData(data));
  }, [0]);

  return (
    <div>
          <Navbar collapseOnSelect expand="lg" className="bg-body-tertiary">
            <Container>
            <Navbar.Brand href="/">
    <img src="logo.png" alt="logo" style={{ width: '50px'}}/>
</Navbar.Brand>


              <Navbar.Brand href="/">Home</Navbar.Brand>
              <Navbar.Toggle aria-controls="responsive-navbar-nav" />
              <Navbar.Collapse id="responsive-navbar-nav">
                <Nav className="me-auto">


                  <NavDropdown title="Categories" id="collapsible-nav-dropdown" style={{ marginTop: '5px'}}>
                    <NavDropdown.Item >
                    <Link to="/product/category/electronics" class="nodecoration">Electronics</Link>
                    
                    </NavDropdown.Item>
                    <NavDropdown.Item >
                    <Link to="/product/category/jewelery" class="nodecoration">Jewelery</Link>
                    
                    </NavDropdown.Item>
                    <NavDropdown.Item >
                    <Link to="/product/category/men's clothing" class="nodecoration">Men's Clothing</Link>
                    
                    </NavDropdown.Item>
                    <NavDropdown.Item>
                      <Link to="/product/category/women's clothing" class="nodecoration">Women's clothing</Link>
          
                    </NavDropdown.Item>

                    

                  </NavDropdown>
                  
                  <h2><Link to="/cart" class="nodecoration" style={{ marginLeft: '1200px', textDecoration: 'none'}}><IoCartOutline /></Link></h2>
                </Nav>
              </Navbar.Collapse>
            </Container>
          </Navbar>
    </div>
  );
}

export default NavbarHome;
