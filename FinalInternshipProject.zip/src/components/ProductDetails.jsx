import React, { useEffect, useState } from "react";
import Button from "react-bootstrap/Button";
import Card from "react-bootstrap/Card";
import Carousel from "react-bootstrap/Carousel";
import Col from "react-bootstrap/Col";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import { useParams } from "react-router-dom";
import "./ProductDetails.css";


function ProductDetails() {
  const [product, setProduct] = useState({});

const {productid}=useParams()

console.log(product)


  useEffect(() => {
    fetch(`https://fakestoreapi.com/products/${productid}`)
      .then((response) => response.json())
      .then((data) => setProduct(data));
  }, [0]);

  const handleSelect = (selectedIndex) => {
    setIndex(selectedIndex);
  };
  return (
    <div style={{ marginTop: '90px' }}>
        
      <Container>
        <Row>
          <Col sm={5}>
            <Carousel activeIndex={0} onSelect={handleSelect}>
              <Carousel.Item>
                <img
                  className="d-block w-100"
                  src={product.image}
                  alt="Third slide"
                />
              </Carousel.Item>
            </Carousel>
          </Col>

          <Col sm={7}>
            <Card style={{ width: "30rem", height: "27rem" }}>
              <p className="new-arrival">NEW</p>

              <Card.Body>
                <Card.Title>{product.title}</Card.Title>
                <Card.Text>
                  {product.description}
                </Card.Text>
              </Card.Body>
            </Card>
            <br />
            <p>
              Price: <span>{product.price}</span>
            </p>
            <label>Quantity: </label>
            <input type="text" name="" id="" value="1" />
            <Button variant="success">Add to Card</Button>{" "}
          </Col>
        </Row>
      </Container>
      
    </div>
  );

  
}

export default ProductDetails;
