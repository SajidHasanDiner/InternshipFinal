import { MDBCarousel, MDBCarouselItem } from 'mdb-react-ui-kit';
import React from 'react';

export default function Carousel() {
  return (
    <MDBCarousel showControls interval={2500} style={{ marginTop: '25px', marginBottom: '50px',height: '300px' }}>
      <MDBCarouselItem itemId={1} interval={250}>
        <img src='https://m.media-amazon.com/images/I/61CiqVTRBEL._SX3000_.jpg' className='d-block w-100' alt='...' />
      </MDBCarouselItem>
      <MDBCarouselItem itemId={2}>
        <img src='https://m.media-amazon.com/images/I/71Ie3JXGfVL._SX3000_.jpg' className='d-block w-100' alt='...' />
      </MDBCarouselItem>
      <MDBCarouselItem itemId={3}>
        <img src='https://m.media-amazon.com/images/I/81KkrQWEHIL._SX3000_.jpg' className='d-block w-100' alt='...' />
      </MDBCarouselItem>
      <MDBCarouselItem itemId={3}>
        <img src='https://m.media-amazon.com/images/I/61zAjw4bqPL._SX3000_.jpg' className='d-block w-100' alt='...' />
      </MDBCarouselItem>
      <MDBCarouselItem itemId={3}>
        <img src='https://m.media-amazon.com/images/I/71nwqPZaNRL._SX3000_.jpg' className='d-block w-100' alt='...' />
      </MDBCarouselItem>
    </MDBCarousel>
  );
}