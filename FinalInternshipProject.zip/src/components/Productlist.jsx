import { useEffect, useState } from "react";
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import "./productlist.css";

function Productlist() {
  const [data, setData] = useState([]);

  useEffect(() => {
    fetch("https://fakestoreapi.com/products")
      .then((response) => response.json())
      .then((data) => setData(data));
  }, [0]);

//   console.log(data);
  return (
    <div className="products-container" >
      {data.map((item, index) => (
        <div key={index} style={{ marginTop: '25px' }}>

          <Card style={{ width: '22rem'}}>
            <div style={{ height: '400px', overflow:'hidden' }}>
            <a href={`/product/${item.id}`}><Card.Img variant="top" src={item.image}/></a>
            </div>
      <Card.Body>
        <Card.Title>{item.title.slice(0,15)}</Card.Title>
        {/* <Card.Text>
          {item.description}
        </Card.Text> */}
        <div className="products-container2">
        <p style={{ padding: '5px' }}>Price {parseInt(item.price)}</p>
        <Button variant="primary" style={{ padding: '2px 50px' }}>Buy</Button>
        </div>
        
      </Card.Body>
    </Card>
        </div>
        
      ))}
    </div>
  );
}

export default Productlist;
